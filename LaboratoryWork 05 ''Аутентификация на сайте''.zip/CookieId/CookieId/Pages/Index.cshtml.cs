using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using CookieId.Models;

namespace CookieId.Pages{
    public class IndexModel : PageModel {
        public string Result { get; set; } = "";
        //  localhost:1111/?id
        public void OnGet(int? id) {
            Student? st = null;
            var cookie = HttpContext.Request.Cookies;
            if (id == null && cookie.ContainsKey("ID")) {
                id = int.Parse(cookie["ID"]);
            }
            else if (id != null) {
                HttpContext.Response.Cookies.Append("ID", id.ToString());
            }
            foreach (var s in Student.All) {
                if (s.Id == id) {
                    st = s;
                }
            }
            Result = $"���: {(st != null ? st.Name : "no name")}";
        }
    }
}
