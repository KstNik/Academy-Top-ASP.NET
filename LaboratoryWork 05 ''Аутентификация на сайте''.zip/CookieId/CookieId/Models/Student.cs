﻿namespace CookieId.Models {
    public class Student {
        public static List<Student> All { get; set; } = new List<Student>() {
            new Student(15, "Ivan"),
            new Student(20, "Petr")
        };
        public int Id { get; set; }
        public string Name { get; set; }
        public Student(int id, string name) {
            Id = id;
            Name = name;
        }
    }
}