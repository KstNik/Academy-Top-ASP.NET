﻿// Controllers/AccountController.cs
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Security.Claims;
public class AccountController : Controller {
    private readonly UserStore userStore;
    public AccountController(UserStore userStore) {
        this.userStore = userStore;
    }
    public IActionResult Register() {
        return View();
    }
    [HttpPost]
    public IActionResult Register(string username, string password, string email) {
        var existingUser = userStore.GetUserByUsername(username);
        if (existingUser != null) {
            if (existingUser.IsDeleted) {
                TempData["Message"] = "Пользователь с таким именем был зарегистрирован, но удалил свой аккаунт, измените имя!";
            }
            else {
                TempData["Message"] = "Пользователь с таким именем уже зарегистрирован, измените имя!";
            }
            return RedirectToAction("Register");
        }
        var user = new User { Id = userStore.Users.Count + 1, Username = username, Password = password, Email = email, IsDeleted = false };
        userStore.AddUser(user);
        TempData["Message"] = "Пользователь успешно зарегистрирован.";
        return RedirectToAction("Index", "Works");
    }
    public IActionResult Login() {
        return View();
    }
    [HttpPost]
    public async Task<IActionResult> Login(string username, string password) {
        var user = userStore.GetUser(username, password);
        if (user != null) {
            var claims = new List<Claim> {
                new Claim(ClaimTypes.NameIdentifier, user.Id.ToString()),
                new Claim(ClaimTypes.Name, user.Username)
            };
            var claimsIdentity = new ClaimsIdentity(claims, "CookieAuth");
            var authProperties = new AuthenticationProperties {
                AllowRefresh = true,
                IsPersistent = true,
            };
            await HttpContext.SignInAsync("CookieAuth", new ClaimsPrincipal(claimsIdentity), authProperties);
            return RedirectToAction("Index", "Works");
        }
        TempData["Message"] = "Пользователь не зарегистрирован или пароль неверный!";
        return View();
    }
    [Authorize]
    public async Task<IActionResult> Logout() {
        await HttpContext.SignOutAsync("CookieAuth");
        return RedirectToAction("Index", "Home");
    }
    [Authorize]
    public IActionResult EditProfile() {
        var userId = int.Parse(User.FindFirst(ClaimTypes.NameIdentifier).Value);
        var user = userStore.Users.First(u => u.Id == userId);
        return View(user);
    }
    [Authorize]
    [HttpPost]
    public IActionResult EditProfile(string email, string password) {
        var userId = int.Parse(User.FindFirst(ClaimTypes.NameIdentifier).Value);
        var user = userStore.Users.First(u => u.Id == userId);
        if (!string.IsNullOrEmpty(email)) {
            user.Email = email;
        }
        if (!string.IsNullOrEmpty(password)) {
            user.Password = password;
        }
        userStore.SaveChanges();
        TempData["Message"] = "Профиль успешно обновлён.";
        return RedirectToAction("Index", "Works");
    }
    [Authorize]
    public IActionResult DeleteAccount() {
        var userId = int.Parse(User.FindFirst(ClaimTypes.NameIdentifier).Value);
        var user = userStore.Users.First(u => u.Id == userId);
        user.IsDeleted = true;
        userStore.SaveChanges();
        TempData["Message"] = "Аккаунт успешно удалён.";
        return RedirectToAction("Logout");
    }
}