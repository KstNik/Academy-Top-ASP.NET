﻿// Controllers/WorksController.cs
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Security.Claims;
[Authorize]
public class WorksController : Controller {
    private readonly WorkStore workStore;
    private readonly UserStore userStore;
    private readonly RatingStore ratingStore;
    private readonly CommentStore commentStore;
    public WorksController(WorkStore workStore, UserStore userStore, RatingStore ratingStore, CommentStore commentStore) {
        this.workStore = workStore;
        this.userStore = userStore;
        this.ratingStore = ratingStore;
        this.commentStore = commentStore;
    }
    public IActionResult Index(string searchTerm, string sortBy) {
        var works = workStore.Works.AsQueryable();
        // Поиск по автору, названию или жанру
        if (!string.IsNullOrEmpty(searchTerm)) {
            works = works.Where(w => w.Author.Contains(searchTerm, StringComparison.OrdinalIgnoreCase) ||
                                      w.Title.Contains(searchTerm, StringComparison.OrdinalIgnoreCase) ||
                                      w.Genre.Contains(searchTerm, StringComparison.OrdinalIgnoreCase));
        }
        // Сортировка
        switch (sortBy) {
            case "genre":
                works = works.OrderBy(w => w.Genre);
                break;
            case "rating":
                works = works.OrderByDescending(w => ratingStore.GetAverageRating(w.Id));
                break;
            case "comments":
                works = works.OrderByDescending(w => commentStore.GetComments(w.Id).Count);
                break;
            default:
                break;
        }
        // Ограничение до Топ-50 произведений
        works = works.Take(50);
        ViewBag.Works = works.ToList();
        return View();
    }
    [HttpGet]
    public IActionResult Create() {
        ViewBag.Genres = new List<string> { "детектив", "история", "приключения", "триллер", "фантастика", "фэнтези" };
        return View();
    }
    [HttpPost]
    public IActionResult Create(string title, string genre, string text) {
        if (string.IsNullOrEmpty(title) || string.IsNullOrEmpty(genre) || string.IsNullOrEmpty(text)) {
            TempData["Message"] = "Все поля должны быть заполнены!";
            ViewBag.Genres = new List<string> { "детектив", "история", "приключения", "триллер", "фантастика", "фэнтези" };
            return View();
        }
        var userId = int.Parse(User.FindFirst(ClaimTypes.NameIdentifier).Value);
        var user = userStore.Users.First(u => u.Id == userId);
        var work = new Work {
            Id = workStore.Works.Count + 1,
            Title = title,
            Genre = genre,
            Text = text,
            Author = user.Username,
            PublishDate = DateTime.Now
        };
        workStore.AddWork(work);
        TempData["Message"] = "Произведение успешно опубликовано.";
        return RedirectToAction("Index");
    }
    [HttpGet]
    public IActionResult Details(int id) {
        var work = workStore.Works.FirstOrDefault(w => w.Id == id);
        if (work == null) {
            return NotFound();
        }
        var comments = commentStore.GetComments(id);
        var averageRating = ratingStore.GetAverageRating(id);
        var users = userStore.Users; // Список всех пользователей
        ViewBag.Comments = comments;
        ViewBag.AverageRating = averageRating == -1 ? "не определён" : Math.Round(averageRating).ToString();
        ViewBag.Users = users; // Передача пользователей в представление
        return View(work);
    }
    [HttpPost]
    public IActionResult RateWork(int workId, int score) {
        var userId = int.Parse(User.FindFirst(ClaimTypes.NameIdentifier).Value);
        var rating = new Rating {
            Id = ratingStore.Ratings.Count + 1,
            WorkId = workId,
            UserId = userId,
            Score = score
        };
        ratingStore.AddRating(rating);
        return RedirectToAction("Details", new { id = workId });
    }
    [HttpPost]
    public IActionResult AddComment(int workId, string content) {
        var userId = int.Parse(User.FindFirst(ClaimTypes.NameIdentifier).Value);
        var comment = new Comment {
            Id = commentStore.Comments.Count + 1,
            WorkId = workId,
            UserId = userId,
            Content = content,
            CommentDate = DateTime.Now
        };
        commentStore.AddComment(comment);
        return RedirectToAction("Details", new { id = workId });
    }
}