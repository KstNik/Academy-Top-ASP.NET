﻿// Models/CommentStore.cs
using System.Text.Json;
public class CommentStore {
    private const string FilePath = "comments.json";
    public List<Comment> Comments { get; private set; }
    public CommentStore() {
        if (File.Exists(FilePath)) {
            var json = File.ReadAllText(FilePath);
            Comments = JsonSerializer.Deserialize<List<Comment>>(json);
        }
        else {
            Comments = new List<Comment>();
        }
    }
    public void AddComment(Comment comment) {
        Comments.Add(comment);
        SaveChanges();
    }
    public List<Comment> GetComments(int workId) {
        return Comments.Where(c => c.WorkId == workId).ToList();
    }
    public void SaveChanges() {
        var json = JsonSerializer.Serialize(Comments);
        File.WriteAllText(FilePath, json);
    }
}