﻿// Models/WorkStore.cs
using System.Text.Json;
public class WorkStore {
    private const string FilePath = "works.json";
    public List<Work> Works { get; private set; }
    public WorkStore() {
        if (File.Exists(FilePath)) {
            var json = File.ReadAllText(FilePath);
            Works = JsonSerializer.Deserialize<List<Work>>(json);
        }
        else {
            Works = new List<Work>();
        }
    }
    public void AddWork(Work work) {
        Works.Add(work);
        SaveChanges();
    }
    public void SaveChanges() {
        var json = JsonSerializer.Serialize(Works);
        File.WriteAllText(FilePath, json);
    }
}