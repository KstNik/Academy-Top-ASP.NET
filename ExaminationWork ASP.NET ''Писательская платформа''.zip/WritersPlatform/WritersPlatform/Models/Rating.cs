﻿// Models/Rating.cs
public class Rating {
    public int Id { get; set; }
    public int WorkId { get; set; }
    public int UserId { get; set; }
    public int Score { get; set; }
}