﻿// Models/UserStore.cs
using System.Text.Json;
public class UserStore {
    private const string FilePath = "users.json";
    public List<User> Users { get; private set; }
    public UserStore() {
        if (File.Exists(FilePath)) {
            var json = File.ReadAllText(FilePath);
            Users = JsonSerializer.Deserialize<List<User>>(json);
        }
        else {
            Users = new List<User>();
        }
    }
    public void AddUser(User user) {
        Users.Add(user);
        SaveChanges();
    }
    public User GetUser(string username, string password) {
        return Users.FirstOrDefault(u => u.Username == username && u.Password == password && !u.IsDeleted);
    }
    public User GetUserByUsername(string username) {
        return Users.FirstOrDefault(u => u.Username == username);
    }
    public void SaveChanges() {
        var json = JsonSerializer.Serialize(Users);
        File.WriteAllText(FilePath, json);
    }
}