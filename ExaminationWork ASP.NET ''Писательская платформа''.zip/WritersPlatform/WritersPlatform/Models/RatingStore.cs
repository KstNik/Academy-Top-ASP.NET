﻿// Models/RatingStore.cs
using System.Text.Json;
public class RatingStore {
    private const string FilePath = "ratings.json";
    public List<Rating> Ratings { get; private set; }
    public RatingStore() {
        if (File.Exists(FilePath)) {
            var json = File.ReadAllText(FilePath);
            Ratings = JsonSerializer.Deserialize<List<Rating>>(json);
        }
        else {
            Ratings = new List<Rating>();
        }
    }
    public void AddRating(Rating rating) {
        var existingRating = Ratings.FirstOrDefault(r => r.WorkId == rating.WorkId && r.UserId == rating.UserId);
        if (existingRating != null) {
            existingRating.Score = rating.Score; // Обновление существующего рейтинга
        }
        else {
            Ratings.Add(rating); // Добавление нового рейтинга
        }
        SaveChanges();
    }
    public double GetAverageRating(int workId) {
        var ratings = Ratings.Where(r => r.WorkId == workId).ToList();
        if (ratings.Any()) {
            return ratings.Average(r => r.Score);
        }
        return -1; // Если рейтинг не определён, возврат -1
    }
    public void SaveChanges() {
        var json = JsonSerializer.Serialize(Ratings);
        File.WriteAllText(FilePath, json);
    }
}