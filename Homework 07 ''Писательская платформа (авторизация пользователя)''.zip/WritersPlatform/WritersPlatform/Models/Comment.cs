﻿// Models/Comment.cs
public class Comment
{
    public int Id { get; set; }
    public int WorkId { get; set; }
    public string Content { get; set; }
    public DateTime CommentDate { get; set; }
}
