﻿// Controllers/AccountController.cs
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Mvc;
using System.Security.Claims;
using System.Linq;
using System.Threading.Tasks;

public class AccountController : Controller
{
    private readonly UserStore userStore;

    public AccountController(UserStore userStore)
    {
        this.userStore = userStore;
    }

    public IActionResult Register()
    {
        return View();
    }

    [HttpPost]
    public IActionResult Register(string username, string password, string email)
    {
        var existingUser = userStore.Users.FirstOrDefault(u => u.Username == username);
        if (existingUser != null)
        {
            TempData["Message"] = "Пользователь с таким именем уже зарегистрирован, измените имя!";
            return RedirectToAction("Register");
        }

        var user = new User { Id = userStore.Users.Count + 1, Username = username, Password = password, Email = email };
        userStore.AddUser(user);

        TempData["Message"] = "Пользователь успешно зарегистрирован.";
        return RedirectToAction("Index", "Works");
    }

    public IActionResult Login()
    {
        return View();
    }

    [HttpPost]
    public async Task<IActionResult> Login(string username, string password)
    {
        var user = userStore.GetUser(username, password);
        if (user != null)
        {
            var claims = new List<Claim>
            {
                new Claim(ClaimTypes.NameIdentifier, user.Id.ToString()),
                new Claim(ClaimTypes.Name, user.Username)
            };

            var claimsIdentity = new ClaimsIdentity(claims, "CookieAuth");
            var authProperties = new AuthenticationProperties
            {
                AllowRefresh = true,
                IsPersistent = true,
            };

            await HttpContext.SignInAsync("CookieAuth", new ClaimsPrincipal(claimsIdentity), authProperties);

            return RedirectToAction("Index", "Works");
        }

        TempData["Message"] = "Пользователь не зарегистрирован или пароль неверный!";
        return View();
    }

    public async Task<IActionResult> Logout()
    {
        await HttpContext.SignOutAsync("CookieAuth");
        return RedirectToAction("Index", "Home");
    }
}
