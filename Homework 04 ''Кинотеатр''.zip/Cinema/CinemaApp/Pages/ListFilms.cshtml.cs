using Microsoft.AspNetCore.Mvc.RazorPages;
using System.Collections.Generic;
using MovieApp.Models;
using MovieApp.Services;

public class ListFilmsModel : PageModel {
    private readonly MovieService _movieService;
    public ListFilmsModel(MovieService movieService) {
        _movieService = movieService;
    }
    public List<Movie> Movies { get; set; }
    public void OnGet() {
        Movies = _movieService.GetMovies();
    }
}