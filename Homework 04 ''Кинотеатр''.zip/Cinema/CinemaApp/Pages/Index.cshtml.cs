using Microsoft.AspNetCore.Mvc.RazorPages;
using MovieApp.Models;
using MovieApp.Services;
using System.Collections.Generic;

public class IndexModel : PageModel {
    private readonly MovieService _movieService;
    public IndexModel(MovieService movieService) {
        _movieService = movieService;
    }
    public List<Session> Sessions { get; set; }
    public void OnGet() {
        Sessions = _movieService.GetSessions();
    }
}