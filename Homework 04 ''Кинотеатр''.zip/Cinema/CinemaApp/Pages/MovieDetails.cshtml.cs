using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using MovieApp.Models;
using MovieApp.Services;
using System.Collections.Generic;
using System.Linq;

public class MovieDetailsModel : PageModel {
    private readonly MovieService _movieService;
    public MovieDetailsModel(MovieService movieService) {
        _movieService = movieService;
    }
    public Movie Movie { get; set; }
    public List<Session> Sessions { get; set; }
    public void OnGet(int id) {
        Movie = _movieService.GetMovies().FirstOrDefault(m => m.Id == id);
        Sessions = _movieService.GetSessions().Where(s => s.Movie.Id == id).ToList();
    }
}