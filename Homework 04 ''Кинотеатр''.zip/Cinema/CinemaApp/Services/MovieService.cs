﻿using System;
using System.Collections.Generic;
using System.Linq;
using MovieApp.Models;

namespace MovieApp.Services {
    public class MovieService {
        private List<Movie> _movies;
        private List<Session> _sessions;
        public MovieService() {
            _movies = new List<Movie> {
                new Movie {
                    Id = 1,
                    Title = "Марсианин",
                    Director = "Ридли Скотт",
                    Screenwriter = "Дрю Годдард",
                    ReleaseDate = new DateTime(2015, 10, 2),
                    Actors = new List<Actor> {
                        new Actor { Name = "Мэтт Дэймон", Role = "Марк Уотни" },
                        new Actor { Name = "Джессика Честейн", Role = "Мелисса Льюис" },
                        new Actor { Name = "Кристен Уиг", Role = "Энни Монтроуз" }
                    },
                    Country = "США",
                    Budget = "$108,000,000",
                    BoxOffice = "$630,000,000",
                    Description = "История астронавта, застрявшего на Марсе, и его попытки выжить с ограниченными ресурсами.",
                    ShortDescription = "Астронавт остался один на Марсе и пытается выжить."
                },
                new Movie {
                    Id = 2,
                    Title = "Терминатор 2: Судный день",
                    Director = "Джеймс Кэмерон",
                    Screenwriter = "Джеймс Кэмерон",
                    ReleaseDate = new DateTime(1991, 7, 3),
                    Actors = new List<Actor> {
                        new Actor { Name = "Арнольд Шварценеггер", Role = "Терминатор" },
                        new Actor { Name = "Линда Хэмилтон", Role = "Сара Коннор" },
                        new Actor { Name = "Эдвард Фёрлонг", Role = "Джон Коннор" }
                    },
                    Country = "США",
                    Budget = "$102,000,000",
                    BoxOffice = "$520,000,000",
                    Description = "Терминатор отправляется назад во времени, чтобы защитить Джона Коннора, который станет лидером сопротивления в войне против машин.",
                    ShortDescription = "Терминатор возвращается чтобы сразиться с более продвинутой моделью."
                },
                new Movie {
                    Id = 3,
                    Title = "Топ Ган: Мэверик",
                    Director = "Джозеф Косински",
                    Screenwriter = "Эрен Крюгер",
                    ReleaseDate = new DateTime(2022, 5, 27),
                    Actors = new List<Actor> {
                        new Actor { Name = "Том Круз", Role = "Пит Митчелл" },
                        new Actor { Name = "Майлз Теллер", Role = "Брэдли Брэдшоу" },
                        new Actor { Name = "Дженнифер Коннелли", Role = "Пенни Бенджамин" }
                    },
                    Country = "США",
                    Budget = "$170,000,000",
                    BoxOffice = "$1,400,000,000",
                    Description = "История лётчика-аса Пита 'Мэверика' Митчелла, который возвращается в элитную школу пилотов в качестве инструктора.",
                    ShortDescription = "Продолжение истории одного из лучших пилотов ВМС США."
                },
                new Movie {
                    Id = 4,
                    Title = "Чудо на Гудзоне",
                    Director = "Клинт Иствуд",
                    Screenwriter = "Тодд Комарники",
                    ReleaseDate = new DateTime(2016, 9, 9),
                    Actors = new List<Actor> {
                        new Actor { Name = "Том Хэнкс", Role = "Чесли 'Салли' Салленбергер" },
                        new Actor { Name = "Аарон Экхарт", Role = "Джефф Скайлз" },
                        new Actor { Name = "Лора Линни", Role = "Лоррейн Салленбергер" }
                    },
                    Country = "США",
                    Budget = "$60,000,000",
                    BoxOffice = "$240,000,000",
                    Description = "История капитана Чесли Салленбергера, который совершил аварийную посадку на реке Гудзон и спас 155 человек.",
                    ShortDescription = "История аварийной посадки на Гудзоне."
                },
                new Movie {
                    Id = 5,
                    Title = "Форд против Феррари",
                    Director = "Джеймс Мэнголд",
                    Screenwriter = "Джез Баттеруорт",
                    ReleaseDate = new DateTime(2019, 11, 15),
                    Actors = new List<Actor> {
                        new Actor { Name = "Мэтт Дэймон", Role = "Кэрролл Шелби" },
                        new Actor { Name = "Кристиан Бэйл", Role = "Кен Майлз" },
                        new Actor { Name = "Джон Бернтал", Role = "Ли Якокка" }
                    },
                    Country = "США",
                    Budget = "$97,000,000",
                    BoxOffice = "$225,000,000",
                    Description = "История гонки Ле-Ман между Ford и Ferrari, и их борьба за победу на трассе.",
                    ShortDescription = "История противостояния компаний Ford и Ferrari."
                }
            };
            _sessions = new List<Session> {
                new Session { Date = DateTime.Today, Time = "10:00", Movie = _movies[0], Price = 300 },
                new Session { Date = DateTime.Today, Time = "13:00", Movie = _movies[0], Price = 300 },
                new Session { Date = DateTime.Today, Time = "16:00", Movie = _movies[1], Price = 350 },
                new Session { Date = DateTime.Today, Time = "19:00", Movie = _movies[1], Price = 350 },
                new Session { Date = DateTime.Today, Time = "22:00", Movie = _movies[1], Price = 400 },
                new Session { Date = DateTime.Today.AddDays(1), Time = "10:00", Movie = _movies[3], Price = 300 },
                new Session { Date = DateTime.Today.AddDays(1), Time = "13:00", Movie = _movies[3], Price = 300 },
                new Session { Date = DateTime.Today.AddDays(1), Time = "16:00", Movie = _movies[2], Price = 350 },
                new Session { Date = DateTime.Today.AddDays(1), Time = "19:00", Movie = _movies[2], Price = 350 },
                new Session { Date = DateTime.Today.AddDays(1), Time = "22:00", Movie = _movies[2], Price = 400 },
                new Session { Date = DateTime.Today.AddDays(2), Time = "10:00", Movie = _movies[0], Price = 300 },
                new Session { Date = DateTime.Today.AddDays(2), Time = "13:00", Movie = _movies[0], Price = 300 },
                new Session { Date = DateTime.Today.AddDays(2), Time = "16:00", Movie = _movies[4], Price = 350 },
                new Session { Date = DateTime.Today.AddDays(2), Time = "19:00", Movie = _movies[4], Price = 350 },
                new Session { Date = DateTime.Today.AddDays(2), Time = "22:00", Movie = _movies[4], Price = 400 }
            };
        }
        public List<Movie> GetMovies() { return _movies; }
        public List<Session> GetSessions() { return _sessions; }
        public Movie GetMovieById(int id) {
            return _movies.FirstOrDefault(m => m.Id == id);
        }
        public List<Session> GetSessionsByMovieId(int movieId) {
            return _sessions.Where(s => s.Movie.Id == movieId).ToList();
        }
    }
}