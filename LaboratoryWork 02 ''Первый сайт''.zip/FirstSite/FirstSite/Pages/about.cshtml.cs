using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace FirstSite.Pages
{
    public class aboutModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
