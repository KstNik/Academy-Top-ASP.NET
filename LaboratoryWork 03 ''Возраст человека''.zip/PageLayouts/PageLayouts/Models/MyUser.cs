﻿namespace PageLayouts {
    public record class MyUser(
        string Name, int Age);
    public class MyGroup {
        public static List<MyUser> All { get; set; } = new List<MyUser>();
    }
}