using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace PageLayouts.Pages
{
    public class _ViewStartModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
