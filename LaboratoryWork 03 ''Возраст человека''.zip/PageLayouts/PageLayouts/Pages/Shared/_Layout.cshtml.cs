using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace PageLayouts.Pages.Shared
{
    public class _LayoutModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
