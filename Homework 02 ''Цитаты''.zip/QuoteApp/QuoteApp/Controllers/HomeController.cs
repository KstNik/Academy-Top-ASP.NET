﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;

namespace QuoteApp.Controllers {
    public class HomeController : Controller {
        private static List<string> Quotes = new List<string>(); // статический список для хранения цитат
        static HomeController() { // статический конструктор для инициализации начальных цитат
            InitializeQuotes();
        }
        public IActionResult Index() { // метод для отображения главной страницы
            return View();
        }
        public IActionResult Today() { // метод для отображения текущей даты
            ViewBag.CurrentDate = DateTime.Now.ToString("D");
            return View();
        }
        [HttpGet]
        public IActionResult Add() { // метод для отображения формы добавления новой цитаты (GET-запрос)
            return View();
        }
        [HttpPost]
        public IActionResult Add(string quote) { // метод для обработки формы добавления новой цитаты (POST-запрос)
            if (!string.IsNullOrEmpty(quote))
                Quotes.Add(quote);
            return RedirectToAction("Index");
        }
        public IActionResult Quote() { // метод для отображения случайной цитаты
            if (Quotes.Count == 0) 
                ViewBag.Quote = "No quotes available.";
            else {
                var random = new Random();
                int index = random.Next(Quotes.Count);
                ViewBag.Quote = Quotes[index];
            }
            return View();
        }
        private static void InitializeQuotes() { // метод для инициализации списка начальных цитат
            Quotes.AddRange(new[] {
                "Идущие на смерть приветствуют тебя!",
                "Фортуна помогает смелым.",
                "И ты Брут, с ними?",
                "Разделяй и властвуй.",
                "Жребий брошен."
            });
        }
    }
}