﻿using System;
using System.Collections.Generic;

namespace MovieApp.Models {
    public class Movie {
        public int Id { get; set; }
        public string Title { get; set; }
        public string Director { get; set; }
        public string Screenwriter { get; set; }
        public DateTime ReleaseDate { get; set; }
        public List<Actor> Actors { get; set; }
        public string Country { get; set; }
        public string Budget { get; set; }
        public string BoxOffice { get; set; }
        public string Description { get; set; }
        public string ShortDescription { get; set; }
    }
    public class Actor {
        public string Name { get; set; }
        public string Role { get; set; }
    }
}