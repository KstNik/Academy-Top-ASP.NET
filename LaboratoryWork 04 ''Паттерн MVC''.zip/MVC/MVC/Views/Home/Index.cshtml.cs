using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace MVC.Views.Home
{
    public class IndexModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
