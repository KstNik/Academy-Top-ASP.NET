using AuthorizationRole.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace AuthorizationRole.Pages {
    public class StarModel : PageModel {
        public Student? star;
        public IActionResult OnGet() {
            var cookie = HttpContext.Request.Cookies;
            int id = -1;
            if (cookie.ContainsKey("UID")) {
                id = int.Parse(cookie["UID"]);
            }
            Student? star = Student.All.Find(s => s.Id == id);
            if (star == null || star.IsStar == false) {
                return Content("Page not found");
            }
            return Page();
        }
    }
}