using AuthorizationRole.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace AuthorizationRole.Pages {
    [IgnoreAntiforgeryToken]
    public class IndexModel : PageModel {
        public string Result { get; set; } = "";
        public void OnPost(string login, string pass) {
            Student? st = Student.All.Find(s => s.Login == login);
            if (st != null) {
                if (st.Pass == pass) {
                    HttpContext.Response.Cookies.Append("UID", st.Id.ToString());
                }
            }
        }
    }
}