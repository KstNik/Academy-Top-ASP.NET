﻿namespace Authorization.Models {
    public class Student {
        public static List<Student> All { get; set; } = new List<Student>() {
            new Student(15, "Ivan", "iv", "1111"),
            new Student(20, "Petr", "pe", "2222")
        };
        public int Id { get; set; }
        public string Name { get; set; }
        public string Login { get; set; }
        public string Pass { get; set; }
        public Student(int id, string name, string login, string pass) {
            Id = id;
            Name = name;
            Login = login;
            Pass = pass;
        }
    }
}