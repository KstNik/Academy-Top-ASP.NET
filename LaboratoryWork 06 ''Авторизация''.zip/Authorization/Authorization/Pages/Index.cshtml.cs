using Authorization.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Authorization.Pages {
    [IgnoreAntiforgeryToken]
    public class IndexModel : PageModel {
        public string Result { get; set; } = "";
        public void OnPost(string login, string pass) {
            Student? st = Student.All.Find(s => s.Login == login);
            if (st != null) {
                if (st.Pass != pass) {
                    st = null;
                }
            }
            Result = $"���: {(st != null ? st.Name : "no name")}";
        }
        public void OnGet(int? id) {
            Student? st = null;
            var cookie = HttpContext.Request.Cookies;
            if (id == null && cookie.ContainsKey("ID")) {
                id = int.Parse(cookie["ID"]);
            }
            else if (id != null) {
                HttpContext.Response.Cookies.Append("ID", id.ToString());
            }
            foreach (var s in Student.All) {
                if (s.Id == id) {
                    st = s;
                }
            }
            Result = $"���: {(st != null ? st.Name : "no name")}";
        }
    }
}