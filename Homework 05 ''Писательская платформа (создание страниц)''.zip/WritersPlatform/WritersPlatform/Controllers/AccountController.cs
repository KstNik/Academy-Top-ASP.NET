﻿// Controllers/AccountController.cs
using Microsoft.AspNetCore.Mvc;
public class AccountController : Controller
{
    public IActionResult Register()
    {
        return View();
    }

    [HttpPost]
    public IActionResult Register(string username, string password, string email)
    {
        // Логика регистрации пользователя

        // Перенаправление на страницу Works после успешной регистрации
        return RedirectToAction("Index", "Works");
    }

    public IActionResult Login()
    {
        return View();
    }

    [HttpPost]
    public IActionResult Login(string username, string password)
    {
        // Логика авторизации пользователя

        // Перенаправление на страницу Works после успешной авторизации
        return RedirectToAction("Index", "Works");
    }

    public IActionResult Logout()
    {
        // Логика выхода пользователя

        // Перенаправление на главную страницу
        return RedirectToAction("Index", "Home");
    }
}
