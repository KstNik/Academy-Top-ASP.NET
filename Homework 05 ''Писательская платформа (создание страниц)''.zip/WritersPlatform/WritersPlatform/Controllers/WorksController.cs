﻿// Controllers/WorksController.cs
using Microsoft.AspNetCore.Mvc;
public class WorksController : Controller
{
    public IActionResult Index()
    {
        return View();
    }

    public IActionResult Details(int id)
    {
        return View();
    }

    public IActionResult Create()
    {
        return View();
    }
}
